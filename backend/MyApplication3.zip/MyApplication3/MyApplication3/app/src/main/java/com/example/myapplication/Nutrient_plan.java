package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.TokenWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Nutrient_plan extends AppCompatActivity {
ImageButton back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrient_plan);
        String[] calory={"1234 kj","4321 kj","5467 kj","8992 kj","6372 kj"} ;
        String[] carbohydrates={"at least 45g","at least 55g","at least 25g","at least 62g","at least 41g"} ;
        String[] protein={"at least 55g","at least 65g","at least 52g","at least 56g","at least 45g"} ;
        String[] fat={"at least 65g","at least 40g","at least 35g","at least 38g","at least 55g"} ;
        String[] water={"at least 3 cups","at least 5 cups","at least 4 cups","at least 3 cups","at least 7 cups"} ;

        String[] vitamin={"A","B","C","D","F"} ;
        String[] limit={"sodium 2400mg","sodium 2000mg","cholesterof 2800mg ","cholesterof 2400mg","sodium 2600mg"} ;
        int randint= ThreadLocalRandom.current().nextInt(0,5);
back=findViewById(R.id.backButton3);
back.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent=new Intent(Nutrient_plan.this,Dislikes.class);
        startActivity(intent);
    }
});
        TextView Calory=findViewById(R.id.caloryTxt);
        TextView Carbo=findViewById(R.id.carhyTxt);
        TextView fatt=findViewById(R.id.fatTxt);
        TextView waterr=findViewById(R.id.waterTxt);
        TextView proteib=findViewById(R.id.prtTxt);
        TextView limits=findViewById(R.id.limit);
        TextView vita=findViewById(R.id.Vitamin);

        Calory.setText(calory[randint]);
        Carbo.setText(carbohydrates[randint]);
        fatt.setText(fat[randint]);
        waterr.setText(water[randint]);
        proteib.setText(protein[randint]);
        limits.setText(limit[randint]);
        vita.setText(("Vitamin "+ vitamin[randint]));


    }
}