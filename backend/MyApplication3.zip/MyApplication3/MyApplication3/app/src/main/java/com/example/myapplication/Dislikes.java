package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.material.textfield.TextInputLayout;

public class Dislikes extends AppCompatActivity {
    ImageButton back_Button;
    Button continue_Button;
    TextInputLayout DislikeDropdown;
    AutoCompleteTextView DislikeDropdownSearch;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dislikes);
        DislikeDropdown=findViewById(R.id.DislikeDropdown);
        DislikeDropdownSearch=findViewById(R.id.DislikesDropdownSearch);
        String [] dislikes_list={"Soy","Dairy","Fish","Egg","Pumpkin","None"};
        ArrayAdapter<String> dislike_adapter=new ArrayAdapter<>(Dislikes.this,R.layout.dislike_dropdown,dislikes_list);
        DislikeDropdownSearch.setAdapter(dislike_adapter);
        DislikeDropdownSearch.setThreshold(1);

        back_Button=(ImageButton) findViewById(R.id.backButton2);
        back_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent( Dislikes.this,Dietary_Requirements.class);
                startActivity(intent);
            }
        });

        continue_Button = (Button) findViewById(R.id.continueButton);
        continue_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                //add where to go @before.class
                Intent intent = new Intent(Dislikes.this, Nutrient_plan.class);
                startActivity(intent);
            }


        });

    }
}